﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace 专治骗子
{
    class Program
    {
        static string userkey = "title";
        static string passwordkey = "content";
        static string submitkey = "_";
        static string submitvalue = "%E6%8F%90%CD%8F%CD%8F%CD%8F%CD%8F%E4%BA%A4";
        static int count = 0;
        static void Main(string[] args)
        {
            for (int i = 0; i < 128; i++) {//128线程
                System.Threading.Thread.Sleep(50);
                new System.Threading.Thread(subThread).Start();
            }
            //if (true) { return; };
            System.Threading.Thread.Sleep(5000);
            while (true) {
                System.Threading.Thread.Sleep(333);
                Console.BackgroundColor = ConsoleColor.DarkBlue;
                Console.Clear();
                System.Threading.Thread.Sleep(333);
                Console.BackgroundColor = ConsoleColor.DarkGreen;
                Console.Clear();
                System.Threading.Thread.Sleep(333);
                Console.BackgroundColor = ConsoleColor.DarkRed;
                Console.Clear();
                System.Threading.Thread.Sleep(333);
                Console.BackgroundColor = ConsoleColor.DarkYellow;
                Console.Clear();
            }

        }
        public static object syncobj = new object();
        public static void subThread() {

            while (true)
            {
                String fakeuser = GenerateRandomSequence("1234567890", 7, 10);
                String fakepass = GenerateRandomSequence("1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM！@#￥%……&*()_+-=[];',./<>?:\"{}\\`~", 6, 12);
                Dictionary<String, String> submitkeyvalue = new Dictionary<string, string>();
                long timeStamp = GetTimestamp();

                submitkeyvalue.Add("callback", "jQuery22009957495884539449_"+timeStamp);



                submitkeyvalue.Add(userkey, fakeuser);
                submitkeyvalue.Add(passwordkey, System.Web.HttpUtility.UrlEncode(fakepass));
                submitkeyvalue.Add(submitkey, (timeStamp+1L).ToString());
                String result = "";
                try
                {
                    result=(Post("http://887265z1.sh.1256980829.clb.myqcloud.com//board.php", submitkeyvalue));
                    count++;
                }
                catch (Exception ex)
                {
                    result =(ex.Message);
                }
                lock (syncobj) {
                    Console.WriteLine("USER=" + fakeuser);
                    Console.WriteLine("PASS=" + fakepass);
                    Console.WriteLine(result);
                    Console.Title = count.ToString();
                    Console.WriteLine("-------------------------------------------");
                }
            }
        }

        public static string GenerateRandomSequence(string charpool, int minlen, int maxlen) {
            StringBuilder sb = new StringBuilder();
            Random rnd = new Random();
            int len = minlen + (rnd.Next() % (maxlen - minlen + 1));
            for (int i = 0; i < len; i++) {
                sb.Append(charpool[rnd.Next() % charpool.Length]);
            }
            return sb.ToString();
        }

        public static string Post(string url, Dictionary<string, string> dic)
        {
            string result = "";
            #region 添加Post 参数
            StringBuilder builder = new StringBuilder();
            int i = 0;
            foreach (var item in dic)
            {
                if (i > 0)
                    builder.Append("&");
                builder.AppendFormat("{0}={1}", item.Key, item.Value);
                i++;
            }
            byte[] data = Encoding.UTF8.GetBytes(builder.ToString());
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url+"?"+builder.ToString());
            req.Timeout = 5000;
            req.Method = "GET";
            req.ContentType = "application/x-www-form-urlencoded";
            req.AllowAutoRedirect = false;
            #endregion
            HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
            Stream stream = resp.GetResponseStream();
            //获取响应内容
            using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
            {
                result = reader.ReadToEnd();
            }
            return result;
        }

        public static long GetTimestamp()
        {
            TimeSpan ts = DateTime.Now.ToUniversalTime() - new DateTime(1970, 1, 1);
            return (long)ts.TotalMilliseconds;    
        }
    }
}
